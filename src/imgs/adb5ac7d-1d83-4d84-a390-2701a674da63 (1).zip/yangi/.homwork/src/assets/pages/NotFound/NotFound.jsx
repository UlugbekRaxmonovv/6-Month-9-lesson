import React from 'react';
import './NotFound.css'

const NotFound = () => {
    return (
        <div>
              <div class="container Arr">
        <h6>404</h6>
        <img src="https://asaxiy.uz/custom-assets/images/murad-animate-gif.gif" alt="" />
     </div>
           
        </div>
    );
}

export default NotFound;
