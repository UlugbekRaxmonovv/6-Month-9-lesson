// OPERATORS-7
// let a = 10;
// let b = 5;
// let c = 0;
// let y = ((a + b + c) ** 2 - (a - b - c) ** 2) ** (1 / 2);
// console.log(y);

// MATH OBJECT ----/////////////////////////////
// console.log(Math.E);
// console.log(Math.PI);
// console.log(Math.SQRT2);
// console.log(Math.sqrt(9));

// console.log(Math.round(3.14));
// console.log(Math.round(3.54));

// console.log(Math.ceil(3.14));
// console.log(Math.ceil(3.0004));
// console.log(Math.ceil(3.9004));

// console.log(Math.floor(3.14));
// console.log(Math.floor(3.54));
// console.log(Math.floor(3.94));
// console.log(Math.floor(-3.94));

// console.log(Math.trunc(3.1409));
// console.log(Math.trunc(3.5409));
// console.log(Math.trunc(3.9409));
// console.log(Math.trunc(-3.9409));

// console.log(Math.pow(3, 4));
// console.log(Math.pow(3, 0));
// console.log(Math.pow(3, 0.5));

// console.log(Math.sqrt(9));
// console.log(Math.abs(-56));
// console.log(Math.abs(0));
// console.log(Math.abs(67));

// console.log(Math.min(23, 67, 4, -6));
// console.log(Math.max(23, 67, 4, 96));

// let a = Math.floor(Math.random() * 10) + 1;
// console.log(a);

// NUMBER ----//////////////////////////
// console.log(Number.EPSILON);
// console.log(Number.MAX_VALUE);
// console.log(Number.MIN_VALUE);
// console.log(Number.MAX_SAFE_INTEGER);
// console.log(Number.MIN_SAFE_INTEGER);
// console.log(Number.POSITIVE_INFINITY);
// console.log(Number.NEGATIVE_INFINITY);
// console.log(Number.NaN);

// let a = 45;
// let b = a.toString();
// console.log(b);
// console.log(typeof b);

// toExponentia()
// let a = 34567;
// console.log(a.toExponential()); // 3.4567 * (10 ** 4)

// toFixed()
// let a = 34.367;
// console.log(a.toFixed(4));

// toPrecision();
// let a = 34.367;
// console.log(a.toPrecision(3));

// parseInt(n)
// console.log(parseInt('a34.456a'));

// parseFloat(n)
// console.log(parseFloat('234..567'));

// Number.isInteger(a);
// console.log(Number.isInteger(34.56));

// STRING => NUMBER  ---//////////////////////
// TYPE CONVERSION    //////////////////////////////
// let a = '345.67';
// console.log(Number(a));
// console.log(typeof Number(a));

// console.log(parseFloat(a));
// console.log(parseInt(a));

// TYPE COERCION   ---/////////////////////////
// console.log(a * 1);
// console.log(a / 1);
// console.log(a - 0);
// console.log(a + 0);
// console.log(+a);

// NUMBER => STRING   ---- ////////////////////////////
// let a = 45.678;
// TYPE CONVERSION ///
// console.log(String(a));
// console.log(a.toString());
// TYPE COERCION  ///
// console.log(a + '');
// console.log(`${a}`);

// Number(a)
// String(b)

// Boolean(c)
// console.log(Boolean(34));
// console.log(Boolean(0));
// console.log(Boolean(3.14));
// console.log(Boolean(-3.14));

// console.log(Boolean('Hello'));
// console.log(Boolean('John Doe'));
// console.log(Boolean(' '));
// console.log(Boolean(''));
// console.log(Boolean([]));
// console.log(Boolean({}));

// console.log(Boolean('0'));
// console.log(Boolean('false'));
// console.log(Boolean(false));
// console.log(Boolean(true));
// console.log(Boolean());

//  LOGICAL OPERATORS - ////
// &&
// let a = 45 && 44;
// let a = 45 && 'Hello';
// let a = 45 && 0;
// let a = NaN && 56;
// let a = undefined && null;

// ||
// let a = 56 || 57;
// let a = 56 || null;
// let a = undefined || 57;
// let a = undefined || null;
// console.log(a);

// !
// let a = !56;
// let a = !0;
// let a = !!undefined;
// console.log(a);

// IF STATEMENT  ---- /////////////////
// let state = 'CA';
// let age = 14;
// if (state == 'CA') {
//   if (age >= 16) {
//     console.log('You can drive.');
//   } else if (age == 15) {
//     console.log('You should try next year');
//   } else {
//     console.log('You are too young');
//   }
// } else {
//   console.log('You are not from CA');
// }

// if (state == 'CA' && age >= 16) {
//   console.log('You can drive.');
// }

// if (34) {
//   console.log('Hello');
// }

// let state = 'CA';
// let answer = state === 'CA' ? 'You can drive' : 'You are not from CA';
// console.log(answer);

// let state = 'CA';
// let age = 15;
// let answer =
//   state === 'CA'
//     ? age >= 16
//       ? 'You can drive'
//       : 'You are yoo young'
//     : 'You are not from CA';
// console.log(answer);

// SWITCH CASE ////////////////////////////
// let numOfDay = 9;
// let day;
// switch (numOfDay) {
//   case 0:
//     day = 'Sunday';
//     break;
//   case 1:
//     day = 'Monday';
//     break;
//   case 2:
//     day = 'Tuesday';
//     break;
//   case 3:
//     day = 'Wednesday';
//     break;
//   case 4:
//     day = 'Thursday';
//     break;
//   case 5:
//     day = 'Friday';
//     break;
//   case 6:
//     day = 'Saturday';
//     break;
//   default:
//     console.log('Invalid day number');
// }
// console.log(day);

// let numOfDay = 6;
// let day;
// switch (numOfDay) {
//   case 1:
//     day = 'Monday';
//     break;
//   case 2:
//     day = 'Tuesday';
//     break;
//   case 3:
//     day = 'Wednesday';
//     break;
//   case 4:
//     day = 'Thursday';
//     break;
//   case 5:
//     day = 'Friday';
//     break;
//   case 6:
//   case 0:
//     day = 'Weekdays';
//     break;
//   default:
//     console.log('Invalid day number');
// }
// console.log(day);
